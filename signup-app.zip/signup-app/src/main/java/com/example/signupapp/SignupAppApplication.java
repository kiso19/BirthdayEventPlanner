package com.example.signupapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SignupAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SignupAppApplication.class, args);
	}

}
