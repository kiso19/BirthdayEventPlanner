package com.example.signupapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignupAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
